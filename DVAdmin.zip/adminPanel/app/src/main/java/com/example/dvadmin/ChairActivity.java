package com.example.dvadmin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.dvadmin.databinding.ActivityChairBinding;
import com.example.dvadmin.databinding.ActivitySofaBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.UUID;

import javax.annotation.Nullable;

public class ChairActivity extends AppCompatActivity {
    ActivityChairBinding binding;

    private String id, title,description,price,resource;
    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChairBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                title=binding.title.getText().toString();
                description=binding.description.getText().toString();
                price=binding.price.getText().toString();
                addProduct();
            }
        });
        binding.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent,100);
            }
        });
        binding.uploadPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.print("tap");
                uploadIMG();
            }
        });

        binding.glbfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                startActivityForResult(intent,200);
            }
        });
        binding.uploadGlb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.print("tap");
                uploadGlb();
            }
        });

    }
    private void uploadGlb() {//glb
        StorageReference storageReference = FirebaseStorage.getInstance().getReference("resources/"+id+".glb");
        storageReference.putFile(uri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        storageReference.getDownloadUrl()
                                .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        FirebaseFirestore.getInstance()
                                                .collection("chair")
                                                .document(id)
                                                .update("resource",uri.toString());
                                        Toast.makeText(ChairActivity.this, "3D Model uploaded successfully", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                });

    }

    private void uploadIMG() {//img pass
        StorageReference storageReference = FirebaseStorage.getInstance().getReference("chair/"+id+".png");
        storageReference.putFile(uri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        storageReference.getDownloadUrl()
                                .addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        FirebaseFirestore.getInstance()
                                                .collection("chair")
                                                .document(id)
                                                .update("image",uri.toString());
                                        Toast.makeText(ChairActivity.this, "Image Uploaded Successfully", Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                });
    }

    private void addProduct() {
        id= UUID.randomUUID().toString();
        ChairModel chairModel = new ChairModel(id,title,description,null,price,true,null);
        FirebaseFirestore.getInstance()
                .collection("chair")
                .document(id)
                .set(chairModel);
        Toast.makeText(this, "Product Added Successfully", Toast.LENGTH_SHORT).show();
    }//title description price

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100){
            assert data != null;
            uri = data.getData();
            binding.image.setImageURI(uri);
        }
        if (requestCode==200){
            assert  data != null;
            uri = data.getData();
            binding.glbfile.setImageURI(uri);
        }
    }
}